﻿namespace TicketResell_API.Controllers.UserController.Model
{
    public class ResendEmail
    {
        public string? email {  get; set; }
    }
}
