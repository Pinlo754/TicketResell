import gallery_icon from './gallery_icon.png'
import help_icon from './help_icon.png'
import pic1 from './gallery1.png'
import pic2 from './gallery2.png'
import pic3 from './gallery3.png'
import pic4 from './gallery4.png'
import search_icon from './search_icon.png'
import send_button from './send_button.png'
import green_dot from './green_dot.png'
import logo from './Logo_festix.png'
import hongle from './avatar.png'
import ticket from './ticket.png'
import avatar from './avatar_icon.png'
import card from './card.png'
const assets = {
    gallery_icon,
    help_icon,
    pic1,
    pic2,
    pic3,
    pic4,
    search_icon,
    send_button,
    green_dot,
    logo,
    hongle,
    ticket,
    avatar,
    card
}

export default assets;